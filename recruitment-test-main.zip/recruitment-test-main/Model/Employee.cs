﻿namespace InterviewTest.Model
{
    public class Employee
    {
        public string Name { get; set; }
        public int Value { get; set; }
    }
}
